# System Flowchart
```text
START
  |
  v
Load protected gateway configuration
  |
  v
Receive authorized ARP observation / synthetic event
  |
  v
Extract IP + MAC
  |
  v
Read persistent SQLite baseline
  |
  +--> New IP? ------ YES --> Store baseline --> Normal
  |
  NO
  |
  +--> Same MAC? ---- YES --> Update last_seen --> Normal
  |
  NO
  |
  +--> Protected gateway? -- YES --> CRITICAL alert
  |                                  |
  |                                  NO --> HIGH alert
  |                                           |
  +-------------------------------> Store alert + update baseline
                                      |
                                      v
                              Dashboard / CSV / API
                                      |
                                     END
```

## Architecture
Authorized Network -> Scapy -> ARP Observation -> Persistent Baseline -> Detection Engine -> SQLite -> Dashboard/CSV/API
