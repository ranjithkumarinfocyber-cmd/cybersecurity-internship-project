# Advanced ARP Spoofing Detection and Network Monitoring System
## Internship Project Report

### Abstract
This project develops a defensive ARP monitoring system using Python and Scapy. It observes authorized ARP traffic, maintains a persistent IP-to-MAC baseline, identifies unexpected MAC changes, prioritizes protected gateway changes, records security events in SQLite, and presents findings through a Flask dashboard. A synthetic JSONL mode provides safe, repeatable demonstrations without network transmission.

### Problem Statement
ARP maps IPv4 addresses to MAC addresses but does not authenticate those claims. Unexpected mapping changes may indicate spoofing, device replacement, failover, DHCP changes, or other legitimate events. A lightweight monitoring system can provide an early security signal.

### Objectives
- Understand ARP and IP-to-MAC relationships.
- Monitor authorized ARP traffic.
- Maintain a persistent baseline.
- Detect unexpected MAC changes.
- Classify protected gateway changes as CRITICAL.
- Store observations and alerts.
- Provide dashboard, API and CSV reporting.
- Demonstrate safely with synthetic data.
- Validate functionality with automated tests.

### Scope
Included: passive ARP monitoring, baseline management, anomaly detection, gateway protection, SQLite logging, dashboard, API, CSV export, offline demo and tests.
Excluded: ARP poisoning, packet injection, credential interception, active disruption and automated counter-attacks.

### Technologies
Python 3.10+, Scapy, Flask, SQLite, HTML/CSS, pytest.

### System Architecture
Authorized Network → Scapy ARP Capture → Observation Layer → Persistent IP/MAC Baseline → Detection Engine → SQLite → Dashboard / CSV / API.

### Detection Logic
1. Receive an ARP observation.
2. Normalize IP and MAC values.
3. Store the observation.
4. Read the existing persistent mapping.
5. If no mapping exists, create it.
6. If the MAC is unchanged, update `last_seen`.
7. If the MAC differs, create an alert.
8. Protected gateway changes are CRITICAL; other changes are HIGH.
9. Update the baseline and retain the event in SQLite.

### Database Design
`baseline(ip, mac, first_seen, last_seen)`
`observations(id, created_at, src_ip, src_mac, protocol, packet_len)`
`alerts(id, created_at, severity, alert_type, src_ip, old_mac, new_mac, message)`

### Dashboard
The dashboard provides observation count, alert count, critical/high counts, baseline count, severity filters, persistent baseline table, recent observations, security alerts and CSV export links. `/api/summary` provides machine-readable summary statistics.

### Testing
Five automated pytest cases verify:
1. New mapping creates a baseline without an alert.
2. Repeated same mapping creates no alert.
3. Workstation MAC change creates HIGH.
4. Protected gateway MAC change creates CRITICAL.
5. JSONL demo contains five events and produces exactly HIGH + CRITICAL alerts.

### Expected Demonstration Result
The five-event synthetic demo creates two alerts:
- 1 HIGH workstation IP/MAC conflict.
- 1 CRITICAL protected gateway MAC change.

### Security and Ethical Considerations
Live monitoring must only be performed on networks for which the operator has permission. The project intentionally avoids packet injection, poisoning, credential collection and counter-attacks. A mapping change is an anomaly, not proof of malicious intent.

### Limitations
- Legitimate device replacement or failover may trigger alerts.
- Passive ARP visibility is local to the broadcast domain.
- Baseline detection depends on the quality of observed traffic.
- The system is an educational defensive monitor, not a replacement for enterprise controls.

### Future Enhancements
PCAP import, SIEM integration, webhooks/email, switch telemetry, DHCP snooping correlation, Dynamic ARP Inspection integration, asset inventory, role-based access and improved anomaly scoring.

### Conclusion
The project provides an end-to-end internship demonstration of network monitoring, detection engineering, persistent event logging, web reporting, automated testing and secure project design. It is packaged as a reproducible, safe defensive application.
