# Advanced ARP Spoofing Detection and Network Monitoring System

## Internship Project – Final Submission

A defensive cybersecurity application that passively observes authorized ARP traffic, maintains a persistent IP-to-MAC baseline, detects unexpected mapping changes, assigns severity to protected gateway changes, stores events in SQLite, and provides a Flask dashboard and CSV exports.

### Key Features
- Passive ARP monitoring with Scapy
- Persistent SQLite baseline
- HIGH and CRITICAL anomaly classification
- Protected gateway configuration
- Safe JSONL offline demo mode
- Flask dashboard with filtering
- Alerts, observations and baseline CSV exports
- Structured application logging
- Automated pytest test suite
- Professional internship report PDF
- No packet injection, poisoning, credential capture, or counter-attack

### Installation
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

### Safe Demo
```bash
python arp_guard.py --demo --reset-db
```
The demo reads `test_data/demo_events.jsonl` and never sends packets.

### Dashboard
```bash
python arp_guard.py --dashboard
```
Open http://127.0.0.1:5000

### Live Mode
Only monitor networks you own or have explicit permission to monitor:
```bash
sudo python arp_guard.py --live --interface eth0 --gateway 192.168.1.1
```
Windows requires an appropriate packet-capture driver such as Npcap.

### Tests
```bash
pytest -q
```

### Project Structure
- `arp_guard.py` – main application
- `templates/dashboard.html` – dashboard UI
- `test_data/demo_events.jsonl` – synthetic test data
- `tests/` – automated tests
- `PROJECT_REPORT.md` – report source
- `PROJECT_REPORT.pdf` – final PDF report
- `PRESENTATION_OUTLINE.md` – viva/presentation slides
- `FLOWCHART.md` – architecture and flowchart
