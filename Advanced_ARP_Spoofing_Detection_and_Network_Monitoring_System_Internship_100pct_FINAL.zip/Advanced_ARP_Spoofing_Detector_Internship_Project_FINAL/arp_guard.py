import argparse
import csv
import io
import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request

try:
    from scapy.all import ARP, sniff
except ImportError:
    ARP = None
    sniff = None

BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "arp_guard.db"
LOG_FILE = BASE_DIR / "arp_guard.log"
DEMO_FILE = BASE_DIR / "test_data" / "demo_events.jsonl"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger("arp_guard")

app = Flask(__name__)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS baseline(
            ip TEXT PRIMARY KEY,
            mac TEXT NOT NULL,
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS observations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            src_ip TEXT NOT NULL,
            src_mac TEXT NOT NULL,
            protocol TEXT NOT NULL,
            packet_len INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS alerts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            severity TEXT NOT NULL,
            alert_type TEXT NOT NULL,
            src_ip TEXT NOT NULL,
            old_mac TEXT NOT NULL,
            new_mac TEXT NOT NULL,
            message TEXT NOT NULL
        );
        """)
        c.commit()


class Detector:
    def __init__(self, protected=None):
        self.protected = {x.strip() for x in (protected or []) if x.strip()}

    def observe(self, ip, mac, packet_len=0):
        if not ip or not mac:
            return None
        ip, mac = str(ip).strip(), str(mac).lower().strip()
        timestamp = now()
        with connect() as c:
            c.execute(
                "INSERT INTO observations(created_at,src_ip,src_mac,protocol,packet_len) VALUES(?,?,?,?,?)",
                (timestamp, ip, mac, "ARP", int(packet_len or 0)),
            )
            row = c.execute("SELECT mac FROM baseline WHERE ip=?", (ip,)).fetchone()
            old = row["mac"] if row else None

            alert = None
            if old is None:
                c.execute(
                    "INSERT INTO baseline(ip,mac,first_seen,last_seen) VALUES(?,?,?,?)",
                    (ip, mac, timestamp, timestamp),
                )
            elif old == mac:
                c.execute("UPDATE baseline SET last_seen=? WHERE ip=?", (timestamp, ip))
            else:
                severity = "CRITICAL" if ip in self.protected else "HIGH"
                alert_type = "GATEWAY_MAC_CHANGE" if ip in self.protected else "IP_MAC_CONFLICT"
                message = f"IP {ip} changed MAC from {old} to {mac}."
                c.execute(
                    """INSERT INTO alerts(created_at,severity,alert_type,src_ip,old_mac,new_mac,message)
                       VALUES(?,?,?,?,?,?,?)""",
                    (timestamp, severity, alert_type, ip, old, mac, message),
                )
                c.execute("UPDATE baseline SET mac=?,last_seen=? WHERE ip=?", (mac, timestamp, ip))
                alert = {
                    "severity": severity, "alert_type": alert_type,
                    "src_ip": ip, "old_mac": old, "new_mac": mac,
                    "message": message
                }
                logger.warning("%s %s", severity, message)
            c.commit()
            return alert


def load_demo_events(path=DEMO_FILE):
    events = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                events.append(json.loads(line))
    return events


def run_demo(reset=False):
    init_db()
    if reset and DB_FILE.exists():
        DB_FILE.unlink()
        init_db()
    detector = Detector({"192.168.1.1"})
    alerts = []
    for event in load_demo_events():
        alert = detector.observe(event["ip"], event["mac"], 42)
        print(f'{event["ip"]} -> {event["mac"]}: {event.get("description","")}')
        if alert:
            alerts.append(alert)
    print(f"Demo complete: {len(alerts)} alert(s).")
    for a in alerts:
        print(f'{a["severity"]}: {a["message"]}')
    return alerts


def live_packet(pkt, detector):
    if ARP is not None and pkt.haslayer(ARP):
        a = pkt[ARP]
        detector.observe(a.psrc, a.hwsrc, len(pkt))


def run_live(interface, protected):
    if sniff is None:
        raise RuntimeError("Scapy is not installed. Run: pip install -r requirements.txt")
    detector = Detector(protected)
    print("LIVE MODE: authorized defensive monitoring only.")
    sniff(iface=interface, filter="arp", prn=lambda p: live_packet(p, detector), store=False)


@app.get("/")
def dashboard():
    severity = request.args.get("severity", "ALL").upper()
    with connect() as c:
        stats = {
            "observations": c.execute("SELECT COUNT(*) FROM observations").fetchone()[0],
            "alerts": c.execute("SELECT COUNT(*) FROM alerts").fetchone()[0],
            "critical": c.execute("SELECT COUNT(*) FROM alerts WHERE severity='CRITICAL'").fetchone()[0],
            "high": c.execute("SELECT COUNT(*) FROM alerts WHERE severity='HIGH'").fetchone()[0],
            "baseline": c.execute("SELECT COUNT(*) FROM baseline").fetchone()[0],
        }
        if severity in {"HIGH", "CRITICAL"}:
            alerts = c.execute(
                "SELECT * FROM alerts WHERE severity=? ORDER BY id DESC LIMIT 100", (severity,)
            ).fetchall()
        else:
            alerts = c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 100").fetchall()
        observations = c.execute(
            "SELECT * FROM observations ORDER BY id DESC LIMIT 100"
        ).fetchall()
        baseline = c.execute("SELECT * FROM baseline ORDER BY ip").fetchall()
    return render_template("dashboard.html", stats=stats, alerts=alerts,
                           observations=observations, baseline=baseline,
                           severity=severity)


@app.get("/api/summary")
def api_summary():
    with connect() as c:
        return jsonify({
            "observations": c.execute("SELECT COUNT(*) FROM observations").fetchone()[0],
            "alerts": c.execute("SELECT COUNT(*) FROM alerts").fetchone()[0],
            "critical": c.execute("SELECT COUNT(*) FROM alerts WHERE severity='CRITICAL'").fetchone()[0],
            "high": c.execute("SELECT COUNT(*) FROM alerts WHERE severity='HIGH'").fetchone()[0],
            "baseline": c.execute("SELECT COUNT(*) FROM baseline").fetchone()[0],
        })


def export_table(table):
    output = io.StringIO()
    with connect() as c:
        rows = c.execute(f"SELECT * FROM {table} ORDER BY 1 DESC").fetchall()
    writer = csv.writer(output)
    if rows:
        writer.writerow(rows[0].keys())
        writer.writerows([tuple(r) for r in rows])
    return Response(
        output.getvalue(), mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={table}.csv"}
    )


@app.get("/alerts.csv")
def alerts_csv():
    return export_table("alerts")


@app.get("/observations.csv")
def observations_csv():
    return export_table("observations")


@app.get("/baseline.csv")
def baseline_csv():
    return export_table("baseline")


def main():
    parser = argparse.ArgumentParser(description="Advanced ARP Guard")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--reset-db", action="store_true")
    parser.add_argument("--dashboard", action="store_true")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--interface")
    parser.add_argument("--gateway", action="append", default=[])
    args = parser.parse_args()

    if args.reset_db and DB_FILE.exists():
        DB_FILE.unlink()
    init_db()

    if args.demo:
        run_demo()
    elif args.live:
        run_live(args.interface, args.gateway)
    else:
        app.run(host="127.0.0.1", port=5000, debug=False)


if __name__ == "__main__":
    main()
