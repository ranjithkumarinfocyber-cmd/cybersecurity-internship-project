# Test Data
The JSONL file contains five synthetic ARP observations. It is used by `--demo` and by the automated tests. It does not transmit traffic and contains no real attack packet capture.
