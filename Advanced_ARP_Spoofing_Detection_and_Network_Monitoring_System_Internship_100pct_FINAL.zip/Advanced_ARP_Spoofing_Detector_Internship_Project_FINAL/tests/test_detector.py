import json
import sqlite3
from pathlib import Path
import pytest

import arp_guard


@pytest.fixture
def isolated_db(tmp_path, monkeypatch):
    db = tmp_path / "test.db"
    monkeypatch.setattr(arp_guard, "DB_FILE", db)
    arp_guard.init_db()
    return db


def test_new_mapping_no_alert(isolated_db):
    d = arp_guard.Detector({"192.168.1.1"})
    assert d.observe("192.168.1.20", "AA:BB:CC:DD:EE:20") is None
    with sqlite3.connect(isolated_db) as c:
        assert c.execute("select count(*) from alerts").fetchone()[0] == 0
        assert c.execute("select mac from baseline where ip='192.168.1.20'").fetchone()[0] == "aa:bb:cc:dd:ee:20"


def test_same_mapping_no_alert(isolated_db):
    d = arp_guard.Detector()
    d.observe("192.168.1.20", "aa:bb:cc:dd:ee:20")
    assert d.observe("192.168.1.20", "AA:BB:CC:DD:EE:20") is None


def test_workstation_change_is_high(isolated_db):
    d = arp_guard.Detector()
    d.observe("192.168.1.20", "aa:bb:cc:dd:ee:20")
    alert = d.observe("192.168.1.20", "de:ad:be:ef:00:20")
    assert alert["severity"] == "HIGH"
    assert alert["alert_type"] == "IP_MAC_CONFLICT"


def test_gateway_change_is_critical(isolated_db):
    d = arp_guard.Detector({"192.168.1.1"})
    d.observe("192.168.1.1", "aa:bb:cc:dd:ee:01")
    alert = d.observe("192.168.1.1", "de:ad:be:ef:00:01")
    assert alert["severity"] == "CRITICAL"
    assert alert["alert_type"] == "GATEWAY_MAC_CHANGE"


def test_jsonl_demo_has_expected_events(isolated_db):
    events = arp_guard.load_demo_events(Path(arp_guard.BASE_DIR) / "test_data" / "demo_events.jsonl")
    assert len(events) == 5
    d = arp_guard.Detector({"192.168.1.1"})
    alerts = [d.observe(e["ip"], e["mac"]) for e in events]
    alerts = [a for a in alerts if a]
    assert [a["severity"] for a in alerts] == ["HIGH", "CRITICAL"]
