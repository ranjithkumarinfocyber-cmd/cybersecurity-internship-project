# Basic Packet Sniffer + ARP Spoofing Detector

A modular Python cybersecurity internship project for passive network observation and ARP anomaly detection.

## Features
- ARP-only packet filtering
- Packet capture with Scapy
- Persistent IP-to-MAC ARP baseline
- Detection of MAC changes for the same IP
- Modular architecture
- Configuration via JSON
- Rotating file logging
- Unit tests
- Documentation, diagrams, report, PPT outline, user manual and test plan

## Ethical Use
Use only on networks and systems you own or are explicitly authorized to monitor. This project is a defensive detector; it does not perform ARP spoofing.

## Requirements
Python 3.10+ and Scapy.

Install:
`pip install -r requirements.txt`

## Run
Linux/macOS (capture may require root):
`python -m packet_sniffer.main --config config/config.json`

Or:
`python scripts/run_detector.py`

Run tests:
`python -m unittest discover -s tests -v`

## Output
- `data/arp_baseline.json` stores trusted IP/MAC observations.
- `logs/detector.log` stores application events.

## Project structure
See `docs/document_index.md`.
