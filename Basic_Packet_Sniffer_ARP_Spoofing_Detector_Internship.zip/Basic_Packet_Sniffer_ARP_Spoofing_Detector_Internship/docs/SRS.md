# Software Requirements Specification (SRS)

## 1. Purpose
The system passively captures ARP traffic and detects suspicious IP-to-MAC changes using a persistent baseline.

## 2. Scope
In scope: ARP packet capture, parsing, baseline management, anomaly detection, logging, configuration and testing.
Out of scope: packet injection, active exploitation, credential collection and automated blocking.

## 3. Functional Requirements
FR-01 Capture only ARP packets.
FR-02 Extract source IP and MAC information.
FR-03 Maintain a persistent IP-to-MAC baseline.
FR-04 Detect unexpected MAC changes.
FR-05 Log observations and alerts.
FR-06 Support configurable interface and paths.
FR-07 Provide unit tests.

## 4. Non-Functional Requirements
Security: defensive/passive operation.
Performance: process packets incrementally.
Maintainability: modular Python components.
Reliability: baseline persists across runs.

## 5. Assumptions
The operator has authorization to monitor the network and suitable packet-capture privileges.
