# Document Index

1. SRS — `docs/SRS.md`
2. System Design — `docs/system_design.md`
3. Architecture Diagram — `docs/diagrams/architecture.mmd`
4. Use-Case Diagram — `docs/diagrams/use_case.mmd`
5. DFD — `docs/diagrams/dfd.mmd`
6. Flowchart — `docs/diagrams/flowchart.mmd`
7. Data Model — `docs/diagrams/data_model.mmd`
8. Final Internship Report — `docs/final_internship_report.md`
9. User Manual — `docs/user_manual.md`
10. Test Plan — `docs/test_plan.md`
11. Test Execution Template — `docs/test_execution_template.md`
12. Viva Q&A — `docs/viva_qa.md`
13. PPT Content — `ppt/internship_presentation.md`
14. README — `README.md`
15. License — `LICENSE`
