# FINAL INTERNSHIP REPORT
## Basic Packet Sniffer + ARP Spoofing Detector

### Abstract
This project implements a defensive Python network-monitoring tool that focuses exclusively on Address Resolution Protocol (ARP) traffic. It maintains a persistent IP-to-MAC baseline and flags unexpected MAC changes, a common indicator associated with ARP spoofing or network reconfiguration.

### 1. Introduction
ARP maps IPv4 addresses to MAC addresses on local networks. Because ARP does not inherently authenticate replies, unexpected mappings can be security-relevant. The project demonstrates packet analysis, baseline-based detection, logging, configuration management and software testing.

### 2. Objectives
- Build an ARP-focused packet sniffer.
- Implement persistent baseline detection.
- Detect suspicious MAC changes.
- Produce maintainable modular source code.
- Provide professional engineering documentation.

### 3. Technologies
Python, Scapy, JSON, unittest, Mermaid diagrams.

### 4. Methodology
Capture ARP frames → parse fields → compare with baseline → log normal/alert events → persist baseline.

### 5. Results
The implementation includes source modules, configuration, logging, persistent baseline, unit tests and a complete documentation package. The tests cover baseline persistence, MAC-change alerts and ARP-only parsing.

### 6. Limitations
A MAC change is an indicator, not definitive proof of an attack. Legitimate causes include DHCP changes, virtualization, failover, device replacement and network administration.

### 7. Future Enhancements
Multi-MAC history, allowlists, alert severity, dashboard visualization, SQLite storage, signed configuration and SIEM integration.

### 8. Conclusion
The project provides a practical foundation for learning defensive packet analysis and ARP anomaly detection while avoiding active network manipulation.
