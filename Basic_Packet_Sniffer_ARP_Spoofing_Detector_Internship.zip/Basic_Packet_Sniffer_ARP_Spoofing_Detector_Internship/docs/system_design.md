# System Design

The system follows a modular pipeline:

Capture Layer → ARP Parser → Baseline Store → Detection Engine → Logger

### Modules
- Capture: Scapy sniff with BPF `arp`.
- Parser: converts packets into `ArpObservation`.
- Baseline: JSON-backed trusted IP/MAC mapping.
- Detector: compares current MAC against stored mapping.
- Logger: rotating application log.
- Configuration: JSON settings.

### Detection Logic
First observation → store as baseline.
Same IP + same MAC → normal.
Same IP + different MAC → alert and update baseline for continued operation.
