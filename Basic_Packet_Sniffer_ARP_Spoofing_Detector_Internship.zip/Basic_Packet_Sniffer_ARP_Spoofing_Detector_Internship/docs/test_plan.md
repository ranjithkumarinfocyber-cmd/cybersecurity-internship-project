# Test Plan

## Objectives
Validate packet filtering, parsing, baseline persistence, detection and configuration.

## Test Cases
TP-01: Non-ARP packet is ignored. Expected: no observation.
TP-02: First ARP observation creates baseline. Expected: baseline_update.
TP-03: Same IP/MAC remains normal. Expected: normal.
TP-04: Same IP/different MAC triggers alert. Expected: alert.
TP-05: Baseline persists after restart. Expected: stored mapping reloads.
TP-06: Logger writes events. Expected: log file contains event.

## Acceptance Criteria
All automated unit tests pass and ARP filtering is enforced using the `arp` capture filter.
