# User Manual

## Installation
1. Install Python 3.10+.
2. Run `pip install -r requirements.txt`.
3. Review `config/config.json`.

## Configuration
`interface`: capture interface or null for Scapy default.
`filter`: must remain `arp`.
`baseline_file`: persistent mapping path.
`log_file`: event log path.
`capture_count`: 0 means continuous capture.
`alert_on_mac_change`: enable/disable alerts.

## Start
`python scripts/run_detector.py --config config/config.json`

If your environment requires elevated capture privileges, run using the operating-system mechanism appropriate for your authorized test environment.

## Stop
Press Ctrl+C. The baseline is saved on exit.

## Interpretation
- `baseline_update`: first trusted observation.
- `normal`: known IP/MAC pair.
- `alert`: known IP observed with a different MAC.

## Troubleshooting
If no packets appear, verify the selected interface and packet-capture permissions. If alerts occur after legitimate topology changes, review and refresh the baseline under controlled administrative procedures.
