# Professional PPT — Basic Packet Sniffer + ARP Spoofing Detector

## Slide 1 — Title
Basic Packet Sniffer + ARP Spoofing Detector
Cybersecurity Internship Project
2026

## Slide 2 — Problem Statement
ARP lacks built-in authentication. Unexpected IP-to-MAC changes may indicate spoofing or legitimate topology changes.

## Slide 3 — Objectives
ARP-only capture, persistent baseline, anomaly detection, logging, testing and maintainable architecture.

## Slide 4 — Technology Stack
Python, Scapy, JSON, unittest, Mermaid.

## Slide 5 — Architecture
Network → ARP Capture → Parser → Detector → Baseline + Logs.

## Slide 6 — Detection Algorithm
First mapping = baseline.
Same mapping = normal.
Different MAC for known IP = alert.

## Slide 7 — Security Design
Passive monitoring; no packet injection, credential collection or automated attack behavior.

## Slide 8 — Testing
Unit tests for baseline, persistence, MAC-change alert and ARP-only filtering.

## Slide 9 — Results
Modular working prototype with configuration, logs, persistent baseline and documentation.

## Slide 10 — Limitations & Future Scope
Reduce false positives with allowlists/history; add dashboard, database and SIEM integration.

## Slide 11 — Conclusion
A practical defensive tool for learning ARP analysis and baseline-based anomaly detection.

## Slide 12 — Q&A
Thank You
