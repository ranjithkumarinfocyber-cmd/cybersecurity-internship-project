import json
from pathlib import Path

class ArpBaseline:
    def __init__(self, path):
        self.path = Path(path)
        self.mapping = {}
        self.load()

    def load(self):
        if self.path.exists():
            try:
                self.mapping = json.loads(self.path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                self.mapping = {}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.mapping, indent=2, sort_keys=True), encoding="utf-8")

    def observe(self, ip, mac):
        previous = self.mapping.get(ip)
        self.mapping[ip] = mac
        return previous

    def is_changed(self, ip, mac):
        return ip in self.mapping and self.mapping[ip].lower() != mac.lower()
