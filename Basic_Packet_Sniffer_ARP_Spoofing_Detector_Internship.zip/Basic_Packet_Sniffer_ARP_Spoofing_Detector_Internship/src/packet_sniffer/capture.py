from .models import ArpObservation

def arp_observation_from_packet(packet):
    # ARP-only filtering is enforced by the BPF filter in start_capture().
    if not packet.haslayer("ARP"):
        return None
    arp = packet["ARP"]
    operation = "request" if getattr(arp, "op", None) == 1 else "reply" if getattr(arp, "op", None) == 2 else str(getattr(arp, "op", "unknown"))
    ip = getattr(arp, "psrc", None)
    mac = getattr(arp, "hwsrc", None)
    if not ip or not mac:
        return None
    return ArpObservation(ip=ip, mac=mac, operation=operation,
                          source_mac=getattr(arp, "hwsrc", None),
                          destination_ip=getattr(arp, "pdst", None))

def start_capture(detector, interface=None, count=0):
    from scapy.all import sniff
    return sniff(iface=interface, filter="arp", prn=_callback(detector), store=False, count=count)

def _callback(detector):
    def callback(packet):
        obs = arp_observation_from_packet(packet)
        if obs:
            detector.process(obs)
    return callback
