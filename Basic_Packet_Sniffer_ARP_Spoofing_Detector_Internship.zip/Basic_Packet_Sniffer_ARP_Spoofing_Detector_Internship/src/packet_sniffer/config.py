import json
from pathlib import Path

def load_config(path="config/config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def ensure_parent(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
