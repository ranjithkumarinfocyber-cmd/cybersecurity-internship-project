from .models import ArpObservation

class ArpSpoofingDetector:
    def __init__(self, baseline, logger=None, alert_on_mac_change=True):
        self.baseline = baseline
        self.logger = logger
        self.alert_on_mac_change = alert_on_mac_change

    def process(self, observation: ArpObservation):
        if not observation.ip or not observation.mac:
            return {"status": "ignored", "reason": "incomplete_arp"}

        changed = self.baseline.is_changed(observation.ip, observation.mac)
        previous = self.baseline.observe(observation.ip, observation.mac)

        if changed and self.alert_on_mac_change:
            msg = f"ARP MAC change detected: IP={observation.ip} OLD={previous} NEW={observation.mac}"
            if self.logger:
                self.logger.warning(msg)
            return {"status": "alert", "ip": observation.ip, "old_mac": previous, "new_mac": observation.mac}

        if self.logger:
            self.logger.info(f"ARP observation: IP={observation.ip} MAC={observation.mac} OP={observation.operation}")
        return {"status": "baseline_update" if previous is None else "normal",
                "ip": observation.ip, "mac": observation.mac}
