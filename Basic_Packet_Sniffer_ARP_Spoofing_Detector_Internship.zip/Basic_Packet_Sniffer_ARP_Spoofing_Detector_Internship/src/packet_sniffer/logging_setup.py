import logging
from logging.handlers import RotatingFileHandler
from .config import ensure_parent

def setup_logging(log_file):
    ensure_parent(log_file)
    logger = logging.getLogger("arp_detector")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    handler = RotatingFileHandler(log_file, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(handler)
    return logger
