import argparse
from .config import load_config
from .logging_setup import setup_logging
from .baseline import ArpBaseline
from .detector import ArpSpoofingDetector
from .capture import start_capture

def main():
    parser = argparse.ArgumentParser(description="Basic Packet Sniffer + ARP Spoofing Detector")
    parser.add_argument("--config", default="config/config.json")
    args = parser.parse_args()
    cfg = load_config(args.config)
    logger = setup_logging(cfg["log_file"])
    baseline = ArpBaseline(cfg["baseline_file"])
    detector = ArpSpoofingDetector(baseline, logger, cfg.get("alert_on_mac_change", True))
    logger.info("Starting ARP-only capture")
    try:
        start_capture(detector, cfg.get("interface"), cfg.get("capture_count", 0))
    except KeyboardInterrupt:
        logger.info("Capture stopped by user")
    finally:
        baseline.save()
        logger.info("Baseline saved")

if __name__ == "__main__":
    main()
