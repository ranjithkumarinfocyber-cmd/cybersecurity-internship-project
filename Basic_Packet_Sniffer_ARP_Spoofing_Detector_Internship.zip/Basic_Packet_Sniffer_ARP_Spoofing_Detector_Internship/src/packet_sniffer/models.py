from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class ArpObservation:
    ip: str
    mac: str
    operation: str
    source_mac: Optional[str] = None
    destination_ip: Optional[str] = None
