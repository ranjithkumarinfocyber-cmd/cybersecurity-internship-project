import tempfile, unittest
from pathlib import Path
from src.packet_sniffer.baseline import ArpBaseline

class TestBaseline(unittest.TestCase):
    def test_persistence_and_change_detection(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "baseline.json"
            b = ArpBaseline(p)
            self.assertFalse(b.is_changed("192.168.1.1", "AA:AA"))
            self.assertIsNone(b.observe("192.168.1.1", "AA:AA"))
            self.assertFalse(b.is_changed("192.168.1.1", "aa:aa"))
            self.assertTrue(b.is_changed("192.168.1.1", "BB:BB"))
            b.save()
            b2 = ArpBaseline(p)
            self.assertEqual(b2.mapping["192.168.1.1"], "AA:AA")

if __name__ == "__main__":
    unittest.main()
