import unittest
from src.packet_sniffer.capture import arp_observation_from_packet

class FakeARP:
    op = 2
    psrc = "192.168.1.10"
    hwsrc = "AA:BB:CC:DD:EE:FF"
    pdst = "192.168.1.1"

class FakePacket:
    def haslayer(self, name): return name == "ARP"
    def __getitem__(self, name): return FakeARP()

class NonArpPacket:
    def haslayer(self, name): return False

class TestCapture(unittest.TestCase):
    def test_arp_only(self):
        self.assertIsNotNone(arp_observation_from_packet(FakePacket()))
        self.assertIsNone(arp_observation_from_packet(NonArpPacket()))

if __name__ == "__main__":
    unittest.main()
