import unittest
from src.packet_sniffer.baseline import ArpBaseline
from src.packet_sniffer.detector import ArpSpoofingDetector
from src.packet_sniffer.models import ArpObservation

class TestDetector(unittest.TestCase):
    def test_first_observation_is_baseline(self):
        d = ArpSpoofingDetector(ArpBaseline("/tmp/nonexistent_arp_baseline.json"))
        result = d.process(ArpObservation("10.0.0.1", "AA:BB", "reply"))
        self.assertEqual(result["status"], "baseline_update")

    def test_mac_change_alert(self):
        b = ArpBaseline("/tmp/nonexistent_arp_baseline2.json")
        d = ArpSpoofingDetector(b)
        d.process(ArpObservation("10.0.0.1", "AA:BB", "reply"))
        result = d.process(ArpObservation("10.0.0.1", "CC:DD", "reply"))
        self.assertEqual(result["status"], "alert")

if __name__ == "__main__":
    unittest.main()
